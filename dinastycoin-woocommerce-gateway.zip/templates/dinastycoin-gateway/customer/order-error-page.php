<section class="woocommerce-order-details">
    <h2 class="woocommerce-order-details__title"><?php echo $method_title ?></h2>
    <p>Payment method not available, please contact the store owner for manual payment</p>
</section>